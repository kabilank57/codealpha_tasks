#Ask meaningful questions about the dataset before analysis

import pandas as pd

# Load the dataset
file_path = r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv"
df = pd.read_csv(file_path)

#its used to know the data types
print(df.dtypes)

#its used to find the shape of the dataset by ROW, COLUMN
print(df.shape)

#its used to provide the new value instead of missing value
print(df.isnull().sum()) 

print(df.head(5))
print(df.tail(5))