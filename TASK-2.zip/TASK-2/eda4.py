#Test hypotheses and validate assumptions using statistics and visualization

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load and clean data
df = pd.read_csv(r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv")
df['Price_Numeric'] = df['Price'].str.replace(r'[^\d.]', '', regex=True).astype(float)

# 2. STATISTICS 
print(f"\n Calculated Mean (Average) Price: £{df['Price_Numeric'].mean():.2f}")
print(f"\n Median (Middle) Price: £{df['Price_Numeric'].median():.2f}")

# 3. VISUALIZATION 
sns.histplot(df['Price_Numeric'], kde=True, color='purple')
plt.title('Book Price Distribution')

# Show the chart on your screen
plt.show()