#Identify trends, patterns and anomalies within the data.

import pandas as pd

# Load the dataset
file_path = r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv"
df = pd.read_csv(file_path)

df['Price_Numeric'] = df['Price'].str.replace(r'[^\d.]', '', regex=True).astype(float)

# What are the most expensive and cheapest books?
most_expensive = df.loc[df['Price_Numeric'].idxmax()] # high price book
cheapest = df.loc[df['Price_Numeric'].idxmin()] # low price book

print(f"\n Most Expensive Book: '{most_expensive['Book Title']}' at £{most_expensive['Price_Numeric']}")
print(f"\n Cheapest Book: '{cheapest['Book Title']}' at £{cheapest['Price_Numeric']}")

# Hypothesis: Are most books priced around £20 to £40? Let's check the average.
avg_price = df['Price_Numeric'].mean()
print(f"\n Average Book Price: £{avg_price:.2f}")