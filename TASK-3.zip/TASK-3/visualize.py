#Transform raw data into visual formats like charts, graphs, and dashboards.
#Use tools like Matplotlib, Seaborn, or Tableau for creating visuals.
#Design visuals that enhance understanding and reveal insights clearly.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv(r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv")
df['Price_Numeric'] = df['Price'].str.replace(r'[^\d.]', '', regex=True).astype(float)

avg_price = df['Price_Numeric'].mean()

sns.set_theme(style="whitegrid")
plt.figure(figsize=(9, 5))

sns.histplot(df['Price_Numeric'], bins=8, kde=True, color='teal', edgecolor='black', alpha=0.7)

plt.axvline(avg_price, color='red', linestyle='dashed', linewidth=2, label=f'Average Price: £{avg_price:.2f}')

plt.title('Distribution of Book Prices (Market Analysis)', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Book Price (£)', fontsize=12)
plt.ylabel('Number of Books', fontsize=12)
plt.legend(fontsize=11)

plt.savefig(r"D:\DATA ANALYST\internship\TASK-2\book_prices_insight.png", dpi=300)
print("Success! Chart saved as 'book_prices_insight.png'")

plt.show()