#Detect potential data issues or problems to address in further analysis. 

import pandas as pd

# 1. Load data
df = pd.read_csv(r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv")

# Tells you if any rows are blank
print(df.isnull().sum())  

#Tells you how many rows are replica
print(f"Number of duplicate books: {df.duplicated().sum()}")

# Shows if columns are stored as text (object) instead of numbers
print(df.dtypes)  