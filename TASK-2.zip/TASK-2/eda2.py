#Explore the data structure, including variables and data types. 

import pandas as pd

# Load the dataset
file_path = r"D:\DATA ANALYST\internship\TASK-2\books_dataset.csv"
df = pd.read_csv(file_path)

#converting the PRICE column (String) into (Decimal)
# This removes EVERYTHING except numbers and decimal points
df['Price_Numeric'] = df['Price'].str.replace(r'[^\d.]', '', regex=True).astype(float)

print("Fixed! 'Price_Numeric' is now a float. Descriptive statistics:")

print(df['Price_Numeric'].describe())