import csv
import requests
from bs4 import BeautifulSoup

url = "https://books.toscrape.com/"
response = requests.get(url)

soup = BeautifulSoup(response.text, "html.parser")

books = soup.find_all("article", class_="product_pod")

with open("books_dataset.csv", mode="w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)

    writer.writerow(["Book Title", "Price"])

    for book in books:

        title = book.h3.a["title"]

        price = book.find("p", class_="price_color").text

        clean_price = price.replace("$", "")

        writer.writerow([title, clean_price])

print("Success! Your CSV file 'books_dataset.csv' has been created.")